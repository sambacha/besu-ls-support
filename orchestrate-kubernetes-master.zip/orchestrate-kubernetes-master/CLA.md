# Sign the CLA

This page is the step-by-step guide to signing the Consensys AG
Individual Contributor License Agreement.

1. First and foremost, read [the current version of the CLA].
   It is written to be as close to plain English as possible.

2. Make an account on [GitHub] if you don't already have one.

3. After creating your first pull request, you will see a merge
   pre-requisite requiring to you read and sign the CLA.

If you have any questions, you can reach us at [support@pegasys.tech].

[github]: https://github.com/
[the current version of the cla]: https://gist.github.com/rojotek/978b48a5e8b68836856a8961d6887992
[support@pegasys.tech]: mailto:support@pegasys.tech
